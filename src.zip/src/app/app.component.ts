import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SalonManagementApp';


  // ngOnInit(): void {
  //   //Toggle Click Function
  //   $("#menuBtn").click(function (e) {
  //     e.preventDefault();
  //     $("#wrapper").toggleClass("toggled");
  //   });
  // }
}
