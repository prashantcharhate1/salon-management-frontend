export interface Service {
    serviceId: number;
    name: string;
}
