import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SidebarComponent } from './sidebar/sidebar.component';

const routes: Routes = [
  {path: 'sidebar' , component: SidebarComponent}
  // { path: 'employees', loadChildren: () => import('../employees/employees.module').then(m => m.EmployeesModule) },
  // { path: 'customers', loadChildren: () => import('../customers/customers.module').then(m => m.CustomersModule) },
  // { path: 'appointments', loadChildren: () => import('../appointments/appointments.module').then(m => m.AppointmentsModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class SiteFrameworkRoutingModule { }
