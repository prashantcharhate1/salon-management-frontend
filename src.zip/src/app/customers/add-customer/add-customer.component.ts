import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomersService } from '../customers.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {
  
  customer:Customer = new Customer();

  constructor(private custService:CustomersService, private router: Router) { }

  ngOnInit(): void {
  }

  addCustomer(form) {
    if(form.valid)
    {
    this.custService.addCustomer(this.customer).subscribe(data => {
      console.log(data),
        error => {
          console.log(error);
        }
    });
    alert("Registration Successful....");
    this.router.navigate(['/customers/list-all-customer']);
  }else{
    alert("Some fields are empty or wrong inputs provided");
  }
  }

}
