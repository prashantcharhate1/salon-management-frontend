export class Customer {
	custId: number;
	address: string;
	custName: string;
	email: string;
    password: string;
    contactNo: number;
	gender: string;
	birthdate: Date;
}
