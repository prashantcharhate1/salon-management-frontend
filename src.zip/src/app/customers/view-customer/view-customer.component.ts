import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Customer } from '../customer';
import { CustomersService } from '../customers.service';

@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.css']
})
export class ViewCustomerComponent implements OnInit {

  customer: Customer;
  custId:number;

  constructor(private customerService: CustomersService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(data => {
      console.log(data.id);
      this.custId = data.id;
    });
    this.customerService.viewCustomer(this.custId).subscribe(data => {
      console.log(data)
      this.customer = data},
      error => console.error(error)
      );
  }

  // DeleteCustomer(cust):void {
  //   if (confirm("Are you sure you want to delete " + cust.custName + "?")) {
  //     this.custService.deleteCustomer(cust.custId).subscribe(
  //        data => {
  //          // refresh the list
  //          this.GetCustomer();
  //          return true;
  //        },
  //        error => {
  //          console.error("Error deleting Customer!");
  //        }
  //     );
  //   }
}
