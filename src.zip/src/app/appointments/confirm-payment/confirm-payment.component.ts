import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Appointment } from '../appointment';
import { AppointmentService } from '../appointment.service';
import { Payment } from '../payment';
import { Service } from '../service';

@Component({
  selector: 'app-confirm-payment',
  templateUrl: './confirm-payment.component.html',
  styleUrls: ['./confirm-payment.component.css']
})
export class ConfirmPaymentComponent implements OnInit {

  payment: Payment = new Payment();
  appId: number;
  serviceId: number;
  service: Service = new Service();
  appointment: Appointment;


  constructor(private appointmentService: AppointmentService,
    private router: Router, private activatedRoute: ActivatedRoute) {
    this.service.serviceRate = 0;
  }

  ngOnInit(): void {

    this.activatedRoute.params.subscribe(data => {
      this.appId = data.id;
    })

    this.appointmentService.getAppointmentById(this.appId).subscribe(
      data => {
        this.appointment = data;
        this.service = data.service;
        this.payment.paymentAmount = this.service.serviceRate;
        console.log(data);
      },
      error => console.log(error)
    );

  }

  saveFormDataTemp(paymentForm) {
    // if (paymentForm.valid) {
    var paymentData = {
      paymentDate: new Date(),
      paymentStatus: "true",
      modeOfPayment: paymentForm.value.mode,
      appId: this.appId
    }
    this.appointmentService.addPayment(paymentData).subscribe(data =>
      console.log(data)
    );
    console.log(paymentData);
    if (paymentForm.value.mode == "CARD")
      this.router.navigate(['appointments/card-payment']);
    else if (paymentForm.value.mode == "CASH")
      this.router.navigate(['appointments/cash-payment']);
    // }
    // else {
    //   alert("Some fields are empty or wrong inputs provided");
    // }
  }

}
