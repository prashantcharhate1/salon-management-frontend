import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Observable } from 'rxjs';
import { Service } from '../appointments/service';
import { Appointment } from './appointment';
import { Payment } from './payment';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {

  constructor(private http: HttpClient) { }

  //to share data between 2 components using Subject
  // private _appointmentData = new Subject<Service>();
  //to expose subject as an observable
  // appointment$ = this._appointmentData.asObservable();

  getServices(): Observable<Service[]> {
    return this.http.get<Service[]>("http://localhost:8080/service/getAllServices/");
  }

  getServiceById(serviceId :number):Observable<Service>{
    return this.http.get<Service>("http://localhost:8080/service/"+serviceId);
  }

  addAppointment(appointment : Appointment) :Observable<Appointment>{
    const uploadData = new FormData();
    console.log(`sending ${appointment}`);
    uploadData.append("appointment", JSON.stringify(appointment));
    return this.http.post<Appointment>("http://localhost:8080/appointment/bookAppointment/", uploadData);
  }

  getAppointmentById(appId:number) : Observable<Appointment>
  {
    return this.http.get<Appointment>("http://localhost:8080/appointment/"+appId);
  }

  // sendAppointmentData(data: Service){
  //   console.log("In sendAppointmentData")
  //   this._appointmentData.next(data);
  // }

  // getAppointmentData(): Observable<Service> {
  //   return this._appointmentData.asObservable();
  // }

  confirmPayment(paymentData): Observable<Payment>{

    return this.http.post<Payment>("http://localhost:8080/payment/register",paymentData);
    
  }

  addPayment(payment:any) :Observable<Payment>{
    return this.http.post<Payment>("http://localhost:8080/payment/register",payment);
  }
}
