import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-all-appointment',
  templateUrl: './list-all-appointment.component.html',
  styleUrls: ['./list-all-appointment.component.css']
})
export class ListAllAppointmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
