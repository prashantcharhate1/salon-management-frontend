import { Time } from "@angular/common";

export class Appointment{
    appId: number;
    service: any;
    appDate: Date;
    appTime: Time;
    customer: number;
    employee: number;
}