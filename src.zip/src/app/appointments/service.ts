export class Service{
    serviceId:number;
    serviceName:string;
    serviceRate:number;
}